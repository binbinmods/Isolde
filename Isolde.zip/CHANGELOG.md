# 0.1.1

Swapped the order of the level 3 and 5 traits.

# 0.1.0

Initial concept
