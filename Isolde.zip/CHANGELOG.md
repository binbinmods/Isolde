# 0.2.0

Breath now applies one extra buffer.

Virtuosic Breath only has 2 activations

Yellow Harbinger of Winter now increases damage and only lasts 2 turns. White and Blue Harbinger of Winter now increase chill/insane charges by 2.

Winter Arrives no longer increases charges

Removed Sight from Silent Aria, increased Insane application to compensate. Reduced activations.

White Owl Song adds one extra Fast. Purple Owl Song adds one less.

Adjusted Obbligato activations.

Cadenza now gives a Neverending Story rather than a Last Requiem.

Removed Fatigue from Bel Canto

# 0.1.1

Swapped the order of the level 3 and 5 traits.

Buffs to Silent Aria and Virtuosic Breath

Cadenza now progresses Stanza.

# 0.1.0

Initial concept
