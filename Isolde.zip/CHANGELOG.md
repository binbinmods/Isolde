# 0.1.1

Swapped the order of the level 3 and 5 traits.

Buffs to Silent Aria and Virtuosic Breath

Cadenza now progresses Stanza.

# 0.1.0

Initial concept
